package com.example.tony_chen.baseconversion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText inputdecimal;
    EditText inputbinary;
    EditText inputHexdecimal;
    Button convert;
    boolean error;
    String valu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputdecimal = (EditText) findViewById(R.id.inputdecimal);
        convert = (Button) findViewById(R.id.convert);
        inputbinary = (EditText) findViewById(R.id.inputbinary);
        inputHexdecimal = (EditText) findViewById(R.id.inputhex);

        inputdecimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputdecimal.getText().clear();
                inputbinary.getText().clear();
                inputHexdecimal.getText().clear();
                }
        });
        inputdecimal.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                valu = "decimal";
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
            }
        );

        inputbinary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputdecimal.getText().clear();
                inputbinary.getText().clear();
                inputHexdecimal.getText().clear();
            }
        });
        inputbinary.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                valu = "binary";
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        inputHexdecimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputdecimal.getText().clear();
                inputbinary.getText().clear();
                inputHexdecimal.getText().clear();
            }
        });
        inputHexdecimal.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                valu = "hexdecimal";
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        convert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v) {
                    error = false;
                        if(valu == "decimal")
                        {
                            String inputd = inputdecimal.getText().toString();
                            int decimalValue = Integer.parseInt(inputd);
                            String binValue = Integer.toBinaryString(decimalValue);
                            inputbinary.setText("" + binValue);

                            String inputb = inputbinary.getText().toString();
                            inputHexdecimal.setText("" + Integer.toHexString(Integer.parseInt(inputb, 2)));
                        }
                        else if(valu == "binary") {
                            String inputb = inputbinary.getText().toString();
                            for (int i = 0; i < inputb.length(); i++) {
                                if ("01".indexOf(inputb.charAt(i)) == -1)
                                    error = true;
                            }
                            if (error) {
                                inputbinary.setError("Please use the numbers 1 and 0 only");
                            }
                            else
                                {
                                inputHexdecimal.setText("" + Integer.toHexString(Integer.parseInt(inputb, 2)));

                                String digits = "0123456789ABCDEF";
                                String inputh = inputHexdecimal.getText().toString().toUpperCase();
                                int val = 0;
                                for (int i = 0; i < inputh.length(); i++) {
                                    char c = inputh.charAt(i);
                                    int d = digits.indexOf(c);
                                    val = 16 * val + d;
                                }
                                inputdecimal.setText("" + val);
                            }
                        }
                        else if(valu == "hexdecimal")
                        {
                            String digits = "0123456789ABCDEFabedef";
                            String inputh = inputHexdecimal.getText().toString().toUpperCase();
                            for (int i = 0; i < inputh.length(); i++) {
                                if ("1234567890ABCDEFabcdef".indexOf(inputh.charAt(i)) == -1)
                                    error = true;
                            }
                            if(error)
                            {
                                inputHexdecimal.setError("Please Enter Numbers and/or letter ABCDEFabcdef only");
                            }
                            else
                                {
                                    int val = 0;
                                    for (int i = 0; i < inputh.length(); i++) {
                                    char c = inputh.charAt(i);
                                    int d = digits.indexOf(c);
                                    val = 16 * val + d;
                                    }
                                    inputdecimal.setText("" + val);

                                    String inputd = inputdecimal.getText().toString();
                                    int decimalValue = Integer.parseInt(inputd);
                                    String binValue = Integer.toBinaryString(decimalValue);
                                    inputbinary.setText("" + binValue);
                                }
                        }
                    }
        });
    }

}
